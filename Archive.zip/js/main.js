/* =========================================================
   DOM ELEMENT REFERENCES
========================================================= */
const logo            = document.querySelector(".logo");
const hamburger       = document.getElementById("hamburger");
const navWrapper      = document.getElementById("navWrapper");
const megaMenu        = document.getElementById("megaMenu");
const megaInner       = document.getElementById("megaInner");
const hItems          = document.querySelectorAll(".h-item");
const accordionHeaders= document.querySelectorAll(".accordion-header");
const navItems        = document.querySelectorAll(".nav-menu li[data-mega]");
const themeToggle     = document.getElementById("themeToggle");

let activePanel  = document.querySelector(".mega-content.active");
let isHoverNav   = false;
let isHoverMega  = false;
let menuOpen     = false;

/* =========================================================
   GSAP PLUGIN REGISTRATION
========================================================= */
gsap.registerPlugin(ScrollTrigger);

/* =========================================================
   HERO LOAD ANIMATIONS
========================================================= */
gsap.from(".hero-eyebrow", { y: 20, opacity: 0, duration: .6, ease: "power2.out" });
gsap.from(".hero h1",      { y: 40, opacity: 0, duration: 1,  delay: .1, ease: "power3.out" });
gsap.from(".hero p",       { y: 20, opacity: 0, duration: .8, delay: .3, ease: "power2.out" });

/* =========================================================
   LOGO HOVER
========================================================= */
if (logo) {
    logo.addEventListener("mouseenter", () => gsap.to(logo, { scale: 1.04, duration: .2, ease: "power2.out" }));
    logo.addEventListener("mouseleave", () => gsap.to(logo, { scale: 1,    duration: .2, ease: "power2.out" }));
}

/* =========================================================
   TEAM SCROLL REVEAL
========================================================= */
gsap.from(".team-card", {
    scrollTrigger: {
        trigger: ".team-section",
        start: "top 80%"
    },
    y: 40,
    opacity: 0,
    duration: .8,
    stagger: .15,
    ease: "power3.out"
});

/* =========================================================
   TOUCH TOGGLE FOR TEAM CARDS (mobile)
   FIX: was registered twice in the original — now registered once
========================================================= */
document.querySelectorAll(".team-card").forEach(card => {
    card.addEventListener("click", () => {
        if (window.innerWidth <= 1024) card.classList.toggle("active");
    });
});

/* =========================================================
   HORIZONTAL ACCORDION — GSAP hover
========================================================= */
hItems.forEach(item => {
    const p = item.querySelector(".h-content p");

    item.addEventListener("mouseenter", () => {
        gsap.to(item, { scale: 1.01, duration: .3,  ease: "power3.out" });
        gsap.to(p,    { opacity: 1, y: 0, duration: .3, ease: "power3.out" });
    });

    item.addEventListener("mouseleave", () => {
        gsap.to(item, { scale: 1,   duration: .25, ease: "power2.out" });
        gsap.to(p,    { opacity: 0, y: 10, duration: .25, ease: "power2.out" });
    });
});

/* =========================================================
   VERTICAL ACCORDION — auto-close others (GSAP)
========================================================= */
accordionHeaders.forEach(header => {
    const item = header.parentElement;
    const body = item.querySelector(".accordion-body");

    // Ensure closed on load
    gsap.set(body, { height: 0, overflow: "hidden" });

    header.addEventListener("click", () => {
        const isOpen = item.classList.contains("active");

        // Close all open items
        accordionHeaders.forEach(otherHeader => {
            const otherItem = otherHeader.parentElement;
            const otherBody = otherItem.querySelector(".accordion-body");
            if (otherItem.classList.contains("active")) {
                gsap.to(otherBody, { height: 0, duration: .35, ease: "power2.inOut" });
                otherItem.classList.remove("active");
            }
        });

        // FIX: removed erroneous gsap.fromTo(".team-card") that was firing
        // inside the accordion open branch, re-animating team cards on every click.
        // FIX: height animation now uses gsap.from() so scrollHeight is read correctly.
        if (!isOpen) {
            gsap.set(body, { height: "auto" });
            gsap.from(body, { height: 0, duration: .35, ease: "power2.inOut" });
            item.classList.add("active");
        }
    });
});

/* =========================================================
   MEGA MENU — open / close / switch panel
========================================================= */

function openMega() {
    gsap.to(megaMenu, {
        opacity: 1,
        y: 0,
        duration: .3,
        ease: "power3.out",
        onStart: () => { megaMenu.style.visibility = "visible"; }
    });
}

function closeMega() {
    gsap.to(megaMenu, {
        opacity: 0,
        y: 12,
        duration: .22,
        ease: "power2.in",
        onComplete: () => { megaMenu.style.visibility = "hidden"; }
    });
    // remove active underline from all nav items
    navItems.forEach(li => li.classList.remove("mega-active"));
}

/* FIX: switchPanel now correctly toggles display so GSAP opacity animations are visible.
   Original: panels had CSS display:none and GSAP only animated opacity on an invisible element. */
function switchPanel(targetClass) {
    const next = document.querySelector(`.mega-content.${targetClass}`);
    if (!next || next === activePanel) return;

    gsap.to(activePanel, {
        opacity: 0,
        y: 8,
        duration: .18,
        onComplete: () => {
            activePanel.classList.remove("active");
            activePanel.style.display = "none";

            next.style.display = "block";
            next.classList.add("active");
            gsap.fromTo(next,
                { opacity: 0, y: -8 },
                { opacity: 1, y: 0, duration: .25, ease: "power3.out" }
            );
            activePanel = next;
        }
    });
}

/* NAV hover */
navItems.forEach(li => {
    li.addEventListener("mouseenter", () => {
        isHoverNav = true;
        navItems.forEach(x => x.classList.remove("mega-active"));
        li.classList.add("mega-active");
        openMega();
        switchPanel(li.dataset.mega);
    });

    li.addEventListener("mouseleave", () => {
        isHoverNav = false;
        setTimeout(checkClose, 60);
    });
});

/* Mega panel hover */
megaInner.addEventListener("mouseenter", () => { isHoverMega = true; });
megaInner.addEventListener("mouseleave", () => {
    isHoverMega = false;
    setTimeout(checkClose, 60);
});

function checkClose() {
    if (!isHoverNav && !isHoverMega) closeMega();
}

/* =========================================================
   HAMBURGER
========================================================= */
if (hamburger) {
    hamburger.addEventListener("click", () => {
        menuOpen = !menuOpen;
        navWrapper.classList.toggle("open", menuOpen);

        gsap.to(".hamburger span:nth-child(1)", {
            rotate: menuOpen ? 45  : 0,
            y:      menuOpen ? 7   : 0,
            duration: .3
        });
        gsap.to(".hamburger span:nth-child(2)", {
            rotate: menuOpen ? -45 : 0,
            y:      menuOpen ? -7  : 0,
            duration: .3
        });
    });
}

/* =========================================================
   MOBILE NAV DROPDOWN TOGGLE
========================================================= */
document.querySelectorAll(".has-dropdown > a").forEach(link => {
    link.addEventListener("click", e => {
        if (window.innerWidth <= 1024) {
            e.preventDefault();
            link.parentElement.classList.toggle("open");
        }
    });
});

/* =========================================================
   RESET ON RESIZE
========================================================= */
window.addEventListener("resize", () => {
    if (window.innerWidth > 1024) {
        navWrapper.classList.remove("open");
        menuOpen = false;
        gsap.set(".hamburger span", { rotate: 0, y: 0 });
    }
});

/* =========================================================
   DARK MODE
   FIX: themeToggle.checked = true was executing before DOM was ready in the
   original load order (scripts were in <head>). Now safe — scripts are at
   bottom of <body> so DOM is fully parsed before this runs.
========================================================= */

// Restore saved theme on load
if (localStorage.getItem("theme") === "dark") {
    document.body.classList.add("dark-mode");
    themeToggle.checked = true;
}

// Toggle on change
themeToggle.addEventListener("change", () => {
    document.body.classList.toggle("dark-mode");
    localStorage.setItem(
        "theme",
        document.body.classList.contains("dark-mode") ? "dark" : "light"
    );
});
